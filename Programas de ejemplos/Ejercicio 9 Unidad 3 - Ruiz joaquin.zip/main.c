/*
Ejercicio 9
Una empresa de seguros procesa la informaci�n de las ventas que han realizado sus 10 promotores. De cada uno de los 10 promotores
se conoce el c�digo de sector donde trabaja (n�mero entre 30 y 37) codificado: 30: Moto - 31: Auto - 32: Camioneta
- 33: Cami�n - 34: �mnibus de Corta distancia - 35: �mnibus de larga distancia - 36: Combis de pasajeros - 37: taxis.
De cada seguro (son 3 tipos de seguros distintos) se conoce el tipo (una letra entre �A� y
�C�), el nombre y su precio. Los tipos de seguro se codifican: �A�: Seguro contra terceros, �B�: Seguro de Incendio y �C�: Seguro Total.
Nota: Leer la informaci�n que se pide, y de acuerdo a eso, �Qu� estructura es la m�s adecuada para el almacenamiento de los datos?
Se pide realizar un programa que permita (utilizando Men� de opciones):
a) Ingresar las ventas de seguros realizadas. Por cada venta se ingresa n�mero de promotor (de 1...10) y tipo de seguro(�A���C�).
 Las ventas no traen ning�n orden espec�fico y termina el ingreso con n�mero de promotor igual a 0.
b) Ingresar un tipo de seguro e indicar en qu� sector se lo vende m�s y cuantos promotores tiene ese sector.
d) Dado un n�mero de sector, indicar cu�l es el seguro que m�s se consume.
e) Indicar para cada tipo de seguro, el nombre y el importe total de venta.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define l 8
#define n 10
#define m 3

typedef struct {
    char tipo;
    char nombre[40];
    float precio;
}seguro;

void cereoventa(int venta[][l]){
    int i,j;
    for(i=0;i<m;i++){
        for(j=0;j<l;j++){
            venta[i][j]=0;
        }
    }
}

int busca_prom(int *p, int prom){
    return p[prom-1]-30;
}

int busca_cod(seguro *s, char cod_seg){
    int i=0;
    while(i<m && s[i].tipo!=cod_seg){
        i++;
    }
    if(i<m){
        return i;
    }else{
        return -1;
    }
}

void ventas(int venta[][l],int *promotor, seguro *s){
    int prom;
    char cod_seg;

    printf("Ingresar numero de promotor: ");
    scanf("%d",&prom);
    fflush(stdin);

    while(prom!=0){
        printf("Ingresar el tipo de seguro: ");
        scanf("%c",&cod_seg);
        fflush(stdin);

        venta[busca_cod(s,cod_seg)][busca_prom(promotor,prom)]++;

        printf("Ingresar numero de promotor: ");
        scanf("%d",&prom);
        fflush(stdin);

    }
}

int cuentapromsector(int sector,int *p){
    int i,cant=0;
    for(i=0;i<n;i++){
        if(p[i]==sector){
            cant++;
        }
    }
    return cant;
}

void punto2(int *p, seguro *s,int venta[][l]){
    char seg;
    int mayor=-1,cant=0,j,i,sector;
    printf("Ingresar tipo de seguro que desea buscar:"),
    scanf("%c",&seg);
    fflush(stdin);

    j=busca_cod(s,seg);

    for(i=0;i<l;i++){
        if(venta[j][i]>mayor){
            mayor=venta[j][i];
            sector=i;
        }
    }
    sector+=30;
    cant=cuentapromsector(sector,p);
    printf("El sector que lo vendio mas fue: %d \n ",sector);
    printf("Este sector posee una cantidad de %d promotores\n",cant);

}

void punto3(int venta[][l],seguro *s){ //arreglo de registro de seguro s[]
    int i,sector,mayor=-1,pos;

    printf("Ingresar sector que desea buscar, el seguro que mas consume:");
    scanf("%d",&sector);
    fflush(stdin);

    for(i=0;i<m;i++){
        if(mayor<venta[i][sector-30]){
            mayor=venta[i][sector-30];
            pos=i;
        }
    }
    printf("El sector %d el seguro que mas consume es: %c \n",sector,s[pos].tipo);
}

void punto4(seguro *s,int venta[][l]){
    int i,j;
    float total;
    for(j=0;j<m;j++){
        total=0;
        for(i=0;i<l;i++){
            total+=venta[j][i];
        }
        total*=s[j].precio;
        printf("Para el tipo de seguro %c el nombre del seguro es %s se recaudo un total de: %f \n",s[j].tipo, s[j].nombre,total);
        system("pause");
    }
}

void menu(int *p, seguro *s,int venta[][l]){
    int opcion;

    do{

        printf("1: Realizar Carga de Ventas.\n");
        printf("2: Ingresar un tipo de seguro e indicar en que sector se lo vende mas y cuantos promotores tiene ese sector.\n");
        printf("3: Dado un numero de sector, indicar cual es el seguro que mas se consume.\n");
        printf("4: Indicar para cada tipo de seguro, el nombre y el importe total de venta.\n");
        printf("0: Salir\n");

        printf("Ingresar lo quiere hacer el programa: ");
        scanf("%d",&opcion);
        fflush(stdin);

        switch(opcion){
            case 1:
                ventas(venta,p,s);
                fflush(stdout);
                break;
            case 2:
                punto2(p,s,venta);
                fflush(stdout);
                break;
            case 3:
                punto3(venta,s);
                fflush(stdout);
                break;
            case 4:
                punto4(s,venta);
                fflush(stdout);
                break;
            default:
                printf("Ingresar de nuevo la opcion: ");
                scanf("%d",&opcion);
                fflush(stdin);
                break;
        }
    }while(opcion!=0);
}

void carga_promotor(int *p){
    int i;
    for(i=0;i<n;i++){
        printf("Ingresar el codigo del sector que trabaja el promotor %d :",i+1);
        scanf("%d",&p[i]);
        fflush(stdin);
    }
}

void carga_seguro(seguro *s){
    int i;
    for(i=0;i<m;i++){
        printf("Ingresar tipo de seguro: ");
        scanf("%c",&s[i].tipo);
        fflush(stdin);
        printf("Ingresar el nombre del seguro: ");
        gets(s[i].nombre);
        fflush(stdin);
        printf("Ingresar el precio del seguro: ");
        scanf("%f",&s[i].precio);
        fflush(stdin);
    }

}



int main()
{

    int p[n],venta[m][l];
    seguro s[m];

    cereoventa(venta);
    carga_promotor(p);
    carga_seguro(s);


    menu(p,s,venta);
    return 0;
}
